-- MySQL dump 10.13  Distrib 5.5.62, for Win64 (AMD64)
--
-- Host: localhost    Database: gasgallery
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `addressid` int(11) NOT NULL,
  `street` varchar(100) DEFAULT NULL,
  `addressline1` varchar(100) DEFAULT NULL,
  `addressline2` varchar(100) DEFAULT NULL,
  `pincode` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `deactivatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`addressid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
REPLACE INTO `address` VALUES (1,'Street','Bazaar Road','','560012',NULL,'Belgavi','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (2,'Street','Bazaar Road','','560012',NULL,'Belgavi','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (3,'Street','Bazaar Road','asd2','562125',NULL,'Belgavi','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (4,'Main Road','Landmark','','555512',NULL,'Bangalore','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (5,'Stree 001','Hanuman Nagar','','534123',NULL,'Bagalkot','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (6,'Street02','AL 01','AL 02','544441',NULL,'Belavadi','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (7,'Street','Adress Line 1','Address Line 2','555551',NULL,'Raichur','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (8,'Indiranagar','1st Main','','560080',NULL,'Bangalore','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (9,'Street Local','Adress Line1','','554433',NULL,'Dharwad','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (10,'Street Local','Adress Line1','','554433',NULL,'Dharwad','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (11,'Bellandur','Ecoworld','','545440',NULL,'Bangalore','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (12,'Bellandur','Ecoworld','','545440',NULL,'Bangalore','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (13,'Street222','Ad Line22','22222','546410',NULL,'Bangalore2','Karnataka2','India2',NULL);
REPLACE INTO `address` VALUES (14,'Varathur','Siddapura','AL2','565656',NULL,'Bangalore','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (15,'Street1','AL1','','561230',NULL,'City','Karnataka','India','2020-08-05 19:21:50');
REPLACE INTO `address` VALUES (16,'Customer Street','CHM Hospital Road','','560070',NULL,'Bangalore','Karanataka','India',NULL);
REPLACE INTO `address` VALUES (17,'Street','AL1','AL2','561245',NULL,'Belgavi','Karnataka','India',NULL);
REPLACE INTO `address` VALUES (18,'Street','Bus Stand Road','','555566',NULL,'Belgavi','Karnataka','India',NULL);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billings`
--

DROP TABLE IF EXISTS `billings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billings` (
  `billingid` int(11) NOT NULL,
  `customerid` int(11) DEFAULT NULL,
  `deliverypersonid` int(11) DEFAULT NULL,
  `deliveredfullcylinderQty` int(11) DEFAULT NULL,
  `billedamount` double DEFAULT NULL,
  `productid` int(11) DEFAULT NULL,
  `paidamount` double DEFAULT NULL,
  `receivedemptycylinderqty` int(11) DEFAULT NULL,
  `billdate` datetime DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createdby` varchar(45) DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `modifiedby` varchar(45) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `rate` decimal(10,4) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`billingid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billings`
--

LOCK TABLES `billings` WRITE;
/*!40000 ALTER TABLE `billings` DISABLE KEYS */;
REPLACE INTO `billings` VALUES (1,1,1,5,6050,1,6050,0,'2020-08-04 00:00:00','2020-08-04 22:53:53','admin','2020-08-04 23:09:36','admin',1,1210.0000,NULL);
REPLACE INTO `billings` VALUES (2,1,1,5,2400,1,6050,0,'2020-08-04 00:00:00','2020-08-04 23:02:28','admin','2020-08-04 23:09:36','admin',1,1210.0000,NULL);
REPLACE INTO `billings` VALUES (3,1,1,5,3600,1,6050,0,'2020-08-04 00:00:00','2020-08-04 23:04:33','admin','2020-08-04 23:09:36','admin',1,1210.0000,NULL);
REPLACE INTO `billings` VALUES (4,1,1,5,1187.5,1,6050,0,'2020-08-04 00:00:00','2020-08-04 23:07:27','admin','2020-08-04 23:09:36','admin',1,1210.0000,NULL);
REPLACE INTO `billings` VALUES (5,1,1,5,1200,1,6050,0,'2020-08-04 00:00:00','2020-08-04 23:08:30','admin','2020-08-04 23:09:36','admin',1,1210.0000,NULL);
REPLACE INTO `billings` VALUES (6,1,1,2,2424,1,2424,0,'2020-08-05 00:00:00','2020-08-05 23:58:12','admin','2020-08-06 00:02:05','admin',2,1212.0000,NULL);
REPLACE INTO `billings` VALUES (7,2,1,4,4444,1,4444,0,'2020-08-05 00:00:00','2020-08-05 23:58:39','admin','2020-08-08 20:14:03','admin',3,1111.0000,NULL);
REPLACE INTO `billings` VALUES (8,2,2,2,2222,1,2222,0,'2020-08-08 00:00:00','2020-08-08 20:16:47','admin','2020-08-08 20:17:59','admin',4,1111.0000,NULL);
REPLACE INTO `billings` VALUES (9,2,1,1,1110,1,1110,0,'2020-08-08 00:00:00','2020-08-08 20:57:18','admin','2020-08-08 20:57:32','admin',5,1110.0000,NULL);
REPLACE INTO `billings` VALUES (10,1,1,1,1200,1,1200,0,'2020-08-08 00:00:00','2020-08-08 21:06:11','admin','2020-08-08 21:06:20','admin',6,1200.0000,NULL);
REPLACE INTO `billings` VALUES (11,1,1,1,1187.5,1,1187.5,0,'2020-08-08 00:00:00','2020-08-08 21:17:35','admin','2020-08-08 21:17:40','admin',7,1187.5000,NULL);
REPLACE INTO `billings` VALUES (12,1,1,1,1187.5,1,1187.5,0,'2020-08-08 00:00:00','2020-08-08 21:25:11','admin','2020-08-08 21:25:25','admin',8,1187.5000,NULL);
REPLACE INTO `billings` VALUES (13,3,1,2,2200,1,2200,0,'2020-08-09 00:00:00','2020-08-09 14:47:54','admin','2020-08-09 14:51:08','admin',9,1100.0000,NULL);
REPLACE INTO `billings` VALUES (14,1,1,5,6000,1,6000,0,'2020-08-09 00:00:00','2020-08-09 17:48:36','admin','2020-08-09 17:48:46','admin',10,1200.0000,NULL);
REPLACE INTO `billings` VALUES (15,4,2,2,2000,13,2000,0,'2020-08-10 00:00:00','2020-08-10 19:32:25','admin','2020-08-10 19:34:14','admin',11,1000.0000,NULL);
REPLACE INTO `billings` VALUES (16,1,1,3,3075,13,0,0,'2020-08-10 00:00:00','2020-08-10 19:33:08','admin','2020-08-10 19:33:08','admin',0,1025.0000,NULL);
REPLACE INTO `billings` VALUES (17,4,3,1,960,13,960,1,'2020-08-10 00:00:00','2020-08-10 19:37:06','admin','2020-08-10 19:37:28','admin',12,960.0000,NULL);
REPLACE INTO `billings` VALUES (18,4,3,4,4320,13,4320,0,'2020-08-10 00:00:00','2020-08-10 19:42:07','admin','2020-08-10 19:42:12','admin',13,1080.0000,NULL);
REPLACE INTO `billings` VALUES (19,4,3,1,960,13,960,0,'2020-08-11 00:00:00','2020-08-11 16:33:32','admin','2020-08-11 16:35:06','admin',14,960.0000,NULL);
REPLACE INTO `billings` VALUES (20,4,3,1,608,12,0,0,'2020-08-11 00:00:00','2020-08-11 16:37:56','admin','2020-08-11 16:37:56','admin',0,608.0000,NULL);
REPLACE INTO `billings` VALUES (21,2,3,2,2400,13,2400,0,'2020-08-11 00:00:00','2020-08-11 17:12:53','admin','2020-08-11 17:15:12','admin',15,1200.0000,NULL);
REPLACE INTO `billings` VALUES (22,2,3,5,5750,13,5750,0,'2020-08-11 00:00:00','2020-08-11 17:33:57','admin','2020-08-11 17:34:57','admin',16,1150.0000,NULL);
REPLACE INTO `billings` VALUES (23,1,3,1,1000,13,1000,0,'2020-08-11 00:00:00','2020-08-11 17:45:26','admin','2020-08-11 17:46:40','admin',17,1000.0000,NULL);
REPLACE INTO `billings` VALUES (24,1,3,2,2000,13,2000,0,'2020-08-11 00:00:00','2020-08-11 18:57:51','admin','2020-08-11 18:58:08','admin',18,1000.0000,NULL);
REPLACE INTO `billings` VALUES (26,0,3,1,1111,15,0,0,'2020-08-12 00:00:00','2020-08-12 11:50:48','admin','2020-08-12 11:50:48','admin',0,1111.0000,'fuel');
/*!40000 ALTER TABLE `billings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `companyid` int(11) NOT NULL,
  `name` varchar(300) DEFAULT NULL,
  `addressid` int(11) DEFAULT NULL,
  `phonenumber` varchar(45) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createdby` varchar(100) DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `modifiedby` varchar(100) DEFAULT NULL,
  `license` varchar(500) DEFAULT NULL,
  `cgst` decimal(10,4) DEFAULT NULL,
  `sgst` decimal(10,4) DEFAULT NULL,
  `reportspath` varchar(1000) DEFAULT NULL,
  `gstnumber` varchar(100) DEFAULT NULL,
  `bankaccountnumber` varchar(45) DEFAULT NULL,
  `bankifsccode` varchar(45) DEFAULT NULL,
  `emailid` varchar(1000) DEFAULT NULL,
  `hsnno` varchar(200) DEFAULT NULL,
  `emailpassword` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`companyid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
REPLACE INTO `company` VALUES (1,'Vinayak Total Gaz Distributor',3,'1231231231','2020-08-04 21:36:07','admin','2020-08-11 13:35:23','admin','ODE0TGlmZXRpbWU=',9.0000,9.0000,'C:\\\\My Computer\\\\Prashant\\\\Projects\\\\Reports_IMS','29AAAAA0000K2ZJ','accountno','ifscode','vinayaktotalgas@gmail.com','HSN55555','NDg2SFNONTU1NTU=');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `CustomerId` int(11) NOT NULL,
  `Name` varchar(300) DEFAULT NULL,
  `AddressId` int(11) DEFAULT NULL,
  `PhoneNumber` varchar(45) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `DiscountPercentage` int(11) DEFAULT NULL,
  `DiscountFlat` int(11) DEFAULT NULL,
  `DepositAmount` int(11) DEFAULT NULL,
  `CreateDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `ModifiedDate` datetime DEFAULT NULL,
  `ModifiedBy` varchar(100) DEFAULT NULL,
  `DeactivateDate` datetime DEFAULT NULL,
  `GstNumber` varchar(100) DEFAULT NULL,
  `EmailId` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`CustomerId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
REPLACE INTO `customer` VALUES (1,'Customer001',5,'0831222221','Goaves',1200,5,0,5000,'2020-08-04 22:38:22','','2020-08-11 15:07:11','admin',NULL,'GSTNo1234','prashant.profession@gmail.com');
REPLACE INTO `customer` VALUES (2,'002Customer',6,'0828833341','Mallamma Circle',1200,10,100,3000,'2020-08-04 22:42:05','','2020-08-04 22:42:25','admin',NULL,NULL,NULL);
REPLACE INTO `customer` VALUES (3,'CustomerNew001',16,'1231231231','Krishna temple Road',1200,5,100,5000,'2020-08-09 12:53:39','','2020-08-09 12:53:39','',NULL,'GST0001','customeremail@123.com');
REPLACE INTO `customer` VALUES (4,'Sankam',18,'9898989898','Gandhi Nagara',1200,5,0,5000,'2020-08-10 19:07:37','','2020-08-11 15:07:50','admin',NULL,'AAAA12312312312','prashant.profession@gmail.com');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dailyreport`
--

DROP TABLE IF EXISTS `dailyreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dailyreport` (
  `dailyreportid` int(11) NOT NULL,
  `soldqty` int(11) DEFAULT NULL,
  `soldamount` double DEFAULT NULL,
  `receivedqty` int(11) DEFAULT NULL,
  `receivedamount` double DEFAULT NULL,
  `transactiondate` date DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `productid` int(11) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createdby` varchar(100) DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `modifiedby` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`dailyreportid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dailyreport`
--

LOCK TABLES `dailyreport` WRITE;
/*!40000 ALTER TABLE `dailyreport` DISABLE KEYS */;
REPLACE INTO `dailyreport` VALUES (1,12,14437.5,0,0,'2020-08-04',50,1,'2020-08-04 22:46:53','admin','2020-08-04 23:09:36','admin');
REPLACE INTO `dailyreport` VALUES (2,6,6868,0,0,'2020-08-05',50,1,'2020-08-05 23:58:12','admin','2020-08-08 20:14:03','admin');
REPLACE INTO `dailyreport` VALUES (3,6,6907,0,0,'2020-08-08',9,1,'2020-08-08 20:15:38','admin','2020-08-08 21:25:25','admin');
REPLACE INTO `dailyreport` VALUES (4,7,8200,0,0,'2020-08-09',69,1,'2020-08-09 14:47:54','admin','2020-08-09 17:48:46','admin');
REPLACE INTO `dailyreport` VALUES (5,0,0,0,0,'2020-08-10',-2,12,'2020-08-10 19:29:52','admin','2020-08-10 19:29:52','admin');
REPLACE INTO `dailyreport` VALUES (6,10,10355,1,0,'2020-08-10',35,13,'2020-08-10 19:30:53','admin','2020-08-11 13:14:39','admin');
REPLACE INTO `dailyreport` VALUES (7,11,12110,0,0,'2020-08-11',85,13,'2020-08-11 16:33:32','admin','2020-08-11 18:58:08','admin');
REPLACE INTO `dailyreport` VALUES (8,1,608,0,0,'2020-08-11',46,12,'2020-08-11 16:37:56','admin','2020-08-11 17:02:29','admin');
REPLACE INTO `dailyreport` VALUES (9,0,0,0,0,'2020-08-12',-9,14,'2020-08-12 08:29:40','admin','2020-08-12 12:26:26','admin');
REPLACE INTO `dailyreport` VALUES (10,0,0,0,0,'2020-08-12',-5,1,'2020-08-12 08:30:31','admin','2020-08-12 08:30:31','admin');
REPLACE INTO `dailyreport` VALUES (11,0,0,0,0,'2020-08-12',46,12,'2020-08-12 08:33:22','admin','2020-08-12 08:33:22','admin');
REPLACE INTO `dailyreport` VALUES (12,0,0,0,0,'2020-08-12',95,13,'2020-08-12 08:33:32','admin','2020-08-12 08:33:32','admin');
REPLACE INTO `dailyreport` VALUES (13,1,1111,0,0,'2020-08-12',106,15,'2020-08-12 11:51:00','admin','2020-08-12 12:20:51','admin');
/*!40000 ALTER TABLE `dailyreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliveryperson`
--

DROP TABLE IF EXISTS `deliveryperson`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliveryperson` (
  `deliverypersonid` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phonenumber` varchar(20) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `addressid` int(11) DEFAULT NULL,
  `deactivatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`deliverypersonid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveryperson`
--

LOCK TABLES `deliveryperson` WRITE;
/*!40000 ALTER TABLE `deliveryperson` DISABLE KEYS */;
REPLACE INTO `deliveryperson` VALUES (1,'ShopKeeper1','9009123123','2020-08-04 22:44:30',7,NULL);
REPLACE INTO `deliveryperson` VALUES (2,'SK2','9845098450','2020-08-04 22:45:28',8,NULL);
REPLACE INTO `deliveryperson` VALUES (3,'Vasanth','1234561238','2020-08-10 19:05:19',17,NULL);
/*!40000 ALTER TABLE `deliveryperson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailtemplate`
--

DROP TABLE IF EXISTS `emailtemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emailtemplate` (
  `emailtemplateid` int(11) NOT NULL,
  `emailid` varchar(250) DEFAULT NULL,
  `displayname` varchar(1000) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `body` varchar(6000) DEFAULT NULL,
  `emailtype` varchar(200) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createdby` varchar(100) DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `modifiedby` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailtemplate`
--

LOCK TABLES `emailtemplate` WRITE;
/*!40000 ALTER TABLE `emailtemplate` DISABLE KEYS */;
REPLACE INTO `emailtemplate` VALUES (1,'prashant.classifieds@gmail.com','Pans Test','ODgzQ2xhc3NpZmllZHNAMTIz','Subject from EmailTemlate','Body testing from email Template','Invoice','2020-08-09 23:27:18','admin','2020-08-11 14:46:12','admin');
REPLACE INTO `emailtemplate` VALUES (2,'prashant.classifieds@gmail.com','Backup User','ODAxQ2xhc3NpZmllZHNAMTIz','Database Backup','Hi, Attaching backup for emergencies.','BackUp','2020-08-12 21:33:49','admin','2020-08-12 21:33:49','admin');
/*!40000 ALTER TABLE `emailtemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice` (
  `invoiceid` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `rateperqty` double DEFAULT NULL,
  `billid` int(11) DEFAULT NULL,
  `customerid` int(11) DEFAULT NULL,
  `productid` int(11) DEFAULT NULL,
  `amountwogst` double DEFAULT NULL,
  `cgst` double DEFAULT NULL,
  `sgst` double DEFAULT NULL,
  `totalamount` double DEFAULT NULL,
  `invoicedate` datetime DEFAULT NULL,
  `createdby` varchar(100) DEFAULT NULL,
  `modifiedby` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `deactivatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`invoiceid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
REPLACE INTO `invoice` VALUES (1,5,1210,1,1,1,3872,1089,1089,6050,'2020-08-04 23:09:35','admin','admin','2020-08-04 23:09:35','2020-08-04 23:09:35',NULL);
REPLACE INTO `invoice` VALUES (2,2,1212,6,1,1,1551.36,436.32,436.32,2424,'2020-08-06 00:00:53','admin','admin','2020-08-06 00:01:19','2020-08-06 00:01:19',NULL);
REPLACE INTO `invoice` VALUES (3,4,1111,7,2,1,2844.16,799.92,799.92,4444,'2020-08-08 20:14:03','admin','admin','2020-08-08 20:14:03','2020-08-08 20:14:03',NULL);
REPLACE INTO `invoice` VALUES (4,2,1111,8,2,1,1422.08,399.96,399.96,2222,'2020-08-08 20:17:36','admin','admin','2020-08-08 20:17:59','2020-08-08 20:17:59',NULL);
REPLACE INTO `invoice` VALUES (5,1,1110,9,2,1,710.4,199.8,199.8,1110,'2020-08-08 20:57:32','admin','admin','2020-08-08 20:57:32','2020-08-08 20:57:32',NULL);
REPLACE INTO `invoice` VALUES (6,1,1200,10,1,1,984,108,108,1200,'2020-08-08 21:06:20','admin','admin','2020-08-08 21:06:20','2020-08-08 21:06:20',NULL);
REPLACE INTO `invoice` VALUES (7,1,1187.5,11,1,1,973.75,106.875,106.875,1187.5,'2020-08-08 21:17:40','admin','admin','2020-08-08 21:17:40','2020-08-08 21:17:40',NULL);
REPLACE INTO `invoice` VALUES (8,1,1187.5,12,1,1,973.75,106.875,106.875,1187.5,'2020-08-08 21:25:25','admin','admin','2020-08-08 21:25:25','2020-08-08 21:25:25',NULL);
REPLACE INTO `invoice` VALUES (9,2,1100,13,3,1,1804,198,198,2200,'2020-08-09 14:51:08','admin','admin','2020-08-09 14:51:08','2020-08-09 14:51:08',NULL);
REPLACE INTO `invoice` VALUES (10,5,1200,14,1,1,4920,540,540,6000,'2020-08-09 17:48:46','admin','admin','2020-08-09 17:48:46','2020-08-09 17:48:46',NULL);
REPLACE INTO `invoice` VALUES (11,2,1000,15,4,13,1640,180,180,2000,'2020-08-10 19:34:14','admin','admin','2020-08-10 19:34:14','2020-08-10 19:34:14',NULL);
REPLACE INTO `invoice` VALUES (12,1,960,17,4,13,787.2,86.4,86.4,960,'2020-08-10 19:37:28','admin','admin','2020-08-10 19:37:28','2020-08-10 19:37:28',NULL);
REPLACE INTO `invoice` VALUES (13,4,1080,18,4,13,3542.4,388.8,388.8,4320,'2020-08-10 19:42:12','admin','admin','2020-08-10 19:42:12','2020-08-10 19:42:12',NULL);
REPLACE INTO `invoice` VALUES (14,1,960,19,4,13,787.2,886.779661016949,886.779661016949,960,'2020-08-11 16:34:57','admin','admin','2020-08-11 16:35:06','2020-08-11 16:35:06',NULL);
REPLACE INTO `invoice` VALUES (15,2,1200,21,2,13,1968,183.050847457627,183.05,2400,'2020-08-11 17:14:45','admin','admin','2020-08-11 17:15:12','2020-08-11 17:15:12',NULL);
REPLACE INTO `invoice` VALUES (16,5,1150,22,2,13,4715,438.56,438.56,5750,'2020-08-11 17:34:18','admin','admin','2020-08-11 17:34:57','2020-08-11 17:34:57',NULL);
REPLACE INTO `invoice` VALUES (17,1,1000,23,1,13,847.46,76.27,76.27,1000,'2020-08-11 17:46:33','admin','admin','2020-08-11 17:46:40','2020-08-11 17:46:40',NULL);
REPLACE INTO `invoice` VALUES (18,2,1000,24,1,13,1694.92,152.54,152.54,2000,'2020-08-11 18:58:07','admin','admin','2020-08-11 18:58:08','2020-08-11 18:58:08',NULL);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `productid` int(11) NOT NULL,
  `weight` varchar(10) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `details` varchar(200) DEFAULT NULL,
  `deactivatedate` datetime DEFAULT NULL,
  `unitrate` decimal(10,4) DEFAULT NULL,
  `cgstrate` decimal(10,4) DEFAULT NULL,
  `sgstrate` decimal(10,4) DEFAULT NULL,
  `isbillable` tinyint(4) DEFAULT NULL,
  `isexpense` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
REPLACE INTO `products` VALUES (1,'17','D-17','Domestic 17 kgs',NULL,1250.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (2,'33','I33','Industrial Gas Cylinder 33 Kgs',NULL,3000.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (3,'1','Pipe','Pipe for domestic gas cylinders',NULL,300.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (4,'2','Stove','Gas Stove',NULL,900.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (5,'12','234','dsaf','2020-08-10 19:08:22',12.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (6,'22','2323123','22','2020-08-10 19:08:20',22.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (7,'33','3333','333','2020-08-10 19:08:17',333.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (8,'44','4444','444','2020-08-10 19:08:15',4444.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (9,'5','5555','55','2020-08-10 19:08:11',555.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (10,'66','666666','66','2020-08-10 19:08:08',666.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (11,'77','7777777','7777','2020-08-10 19:08:05',777.0000,NULL,NULL,NULL,NULL);
REPLACE INTO `products` VALUES (12,'12','D12','Domestic 12 Kgs',NULL,640.0000,2.5000,2.5000,1,NULL);
REPLACE INTO `products` VALUES (13,'17','C17','Commercial 17 Kgs Gas Cylinder',NULL,1030.0000,9.0000,9.0000,1,NULL);
REPLACE INTO `products` VALUES (14,'2','Reg','Regulator Test',NULL,200.0000,2.5000,2.5000,0,NULL);
REPLACE INTO `products` VALUES (15,'1','Expense','Expense detail product',NULL,1.0000,0.0000,0.0000,0,1);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockentry`
--

DROP TABLE IF EXISTS `stockentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stockentry` (
  `stockentryid` int(11) NOT NULL,
  `receiveddate` datetime DEFAULT NULL,
  `productid` int(11) DEFAULT NULL,
  `quantity` double DEFAULT NULL,
  `receivedbyid` int(11) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `createdby` varchar(45) DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `modifiedby` varchar(45) DEFAULT NULL,
  `unitrate` decimal(10,4) DEFAULT NULL,
  `paidamount` double DEFAULT NULL,
  `cgstpaid` decimal(10,4) DEFAULT NULL,
  `sgstpaid` decimal(10,4) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `billedamount` double DEFAULT NULL,
  PRIMARY KEY (`stockentryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockentry`
--

LOCK TABLES `stockentry` WRITE;
/*!40000 ALTER TABLE `stockentry` DISABLE KEYS */;
REPLACE INTO `stockentry` VALUES (1,'2020-08-04 00:00:00',1,50,1,'2020-08-04 22:46:53','admin','2020-08-04 22:46:53','admin',1250.0000,62500,11250.0000,11250.0000,0,62500);
REPLACE INTO `stockentry` VALUES (2,'2020-08-08 00:00:00',1,9,1,'2020-08-08 20:15:38','admin','2020-08-08 20:15:38','admin',1250.0000,11250,2025.0000,2025.0000,0,11250);
REPLACE INTO `stockentry` VALUES (3,'2020-08-09 00:00:00',1,10,1,'2020-08-09 17:24:56','admin','2020-08-09 00:00:00','admin',1200.0000,0,1080.0000,1080.0000,0,12000);
REPLACE INTO `stockentry` VALUES (4,'2020-08-09 00:00:00',1,50,1,'2020-08-09 17:47:56','admin','2020-08-09 17:47:56','admin',1250.0000,0,5625.0000,5625.0000,0,62500);
REPLACE INTO `stockentry` VALUES (5,'2020-08-10 00:00:00',12,5,3,'2020-08-10 19:29:52','admin','2020-08-10 19:29:52','admin',550.0000,0,247.5000,247.5000,0,2750);
REPLACE INTO `stockentry` VALUES (6,'2020-08-10 00:00:00',13,35,3,'2020-08-10 19:30:53','admin','2020-08-10 00:00:00','admin',900.0000,0,2835.0000,2835.0000,0,31500);
REPLACE INTO `stockentry` VALUES (7,'2020-08-11 00:00:00',13,50,3,'2020-08-11 16:43:32','admin','2020-08-11 00:00:00','admin',1234.0000,0,5553.0000,5553.0000,0,61700);
REPLACE INTO `stockentry` VALUES (8,'2020-08-11 00:00:00',12,10,3,'2020-08-11 16:43:50','admin','2020-08-11 00:00:00','admin',666.0000,0,599.4000,599.4000,0,6660);
REPLACE INTO `stockentry` VALUES (9,'2020-08-12 00:00:00',14,5,3,'2020-08-12 08:29:40','admin','2020-08-12 00:00:00','admin',200.0000,0,90.0000,90.0000,0,1000);
REPLACE INTO `stockentry` VALUES (10,'2020-08-12 00:00:00',1,2,2,'2020-08-12 08:30:31','admin','2020-08-12 08:30:31','admin',1250.0000,0,225.0000,225.0000,0,2500);
REPLACE INTO `stockentry` VALUES (11,'2020-08-12 00:00:00',12,5,1,'2020-08-12 08:33:22','admin','2020-08-12 08:33:22','admin',640.0000,0,288.0000,288.0000,0,3200);
REPLACE INTO `stockentry` VALUES (12,'2020-08-12 00:00:00',13,10,1,'2020-08-12 08:33:32','admin','2020-08-12 08:33:32','admin',1030.0000,0,927.0000,927.0000,0,10300);
REPLACE INTO `stockentry` VALUES (13,'2020-08-12 00:00:00',15,100,3,'2020-08-12 11:52:58','admin','2020-08-12 11:52:58','admin',1.0000,0,9.0000,9.0000,0,100);
/*!40000 ALTER TABLE `stockentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplier` (
  `supplierid` int(11) NOT NULL,
  `phonenumber` varchar(45) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `addressid` int(11) DEFAULT NULL,
  `createdby` varchar(100) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `modifiedby` varchar(100) DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `suppliercol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`supplierid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
REPLACE INTO `supplier` VALUES (1,'9845000001','Vendor Name1',4,'admin','2020-08-04 00:00:00','admin','2020-08-09 16:56:14',NULL);
REPLACE INTO `supplier` VALUES (2,'9992222222','Dealer2',13,'admin','2020-08-05 00:00:00','admin','2020-08-05 19:03:51',NULL);
REPLACE INTO `supplier` VALUES (3,'9902012340','Dealer3',14,'admin','2020-08-05 00:00:00','admin','2020-08-05 00:00:00',NULL);
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  `deactivatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` VALUES (1,'admin','NzU5cm9vdA==',NULL);
REPLACE INTO `users` VALUES (2,'superuser','NDIzc3VwZXJwb3dlcjY2NjY2Ng==',NULL);
REPLACE INTO `users` VALUES (3,'suma','MTQzc3VtYUAxMjM=','2020-08-10 19:28:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-12 22:03:56

